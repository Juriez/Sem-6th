package math;

import org.junit.jupiter.api.Test;

public class MyMathTest {
    @Test
    void factorial() {
    }

    @Test
    void isPrime() {
    }
}
